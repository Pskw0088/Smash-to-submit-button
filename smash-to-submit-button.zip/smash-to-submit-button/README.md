# Smash to submit button

A Pen created on CodePen.io. Original URL: [https://codepen.io/pskw00/pen/JjeXazQ](https://codepen.io/pskw00/pen/JjeXazQ).

